import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  @Input() data = [];
  colSortState = {};
  expand(rowIndex: number) {
    this.data[rowIndex].expand = !this.data[rowIndex].expand;
  }

  sort(col: string){
   let dir = this.colSortState[col] === 0 ? 1 : 0;
   this.colSortState[col] = dir;
   this.data = [...this.data.sort((row1, row2) => {
      if(row1[col] > row2[col]) {
        return dir === 0 ? -1 : 1;
      } else
        return dir === 0 ? 1 : -1;
    })];
  }
}
